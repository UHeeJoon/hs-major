package com.app.hanshin.counseling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CounselingApplicationTests {

	@Test
	void contextLoads() {
	}

}
