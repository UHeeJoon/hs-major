package com.app.hanshin.counseling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CounselingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CounselingApplication.class, args);
	}

}
